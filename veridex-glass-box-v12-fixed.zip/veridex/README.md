# Veridex — Glass Box UI Preview

A **light, NVIDIA-green-inspired**, interactive Streamlit prototype for the HackUTD Nemotron challenge. This is an independent student concept, not an official NVIDIA product.

## Run locally (macOS / Linux)

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
streamlit run frontend/app.py
```

Open http://localhost:8501 if it doesn't open automatically.

## What works

- Light dashboard with a dark technical telemetry panel
- Interactive Developer / Executive / Architecture tabs
- Findings filters, selection, and details
- Step-through or full scripted demo timeline
- Before-and-after SQL injection patch preview
- Real `ast.parse()` syntax validation of the **static demo patch**
- Download a unified diff `.patch` file
- Local UI feedback capture (not sent to any model)

## Important limitations

This is **DEMO MODE**. It does **not** connect to NVIDIA Nemotron, execute OpenGrep, analyze arbitrary repositories, or autonomously remediate code. Example findings, model actions, and scan clearance are simulated and clearly labeled. Exported patches are examples requiring human review. No user-provided project code is executed.

## Design

A restrained white / soft-gray workspace with NVIDIA-inspired `#76B900` accents, selective dark technical panels, bento-like cards, and minimal animation. Product name is temporary until the team selects a final name.

## v3 motion preview

The Developer workspace includes a CSS 3D rotating Nemotron-inspired geometric core, state-aware workflow pills, and subtle activity entry transitions. Motion is decorative and reflects **simulated** demo progress only. The core is implemented in CSS (no external 3D model or GPU dependency). Operating systems with reduced-motion preference disable the animation.

## v4 — Evidence-driven remediation preview

New interactive elements:

- **Patch Arena:** switch between two prewritten SQL query patch candidates, one safe-looking and one intentionally still vulnerable. This is a scenario, not a Nemotron-generated comparison.
- **Adversarial Review:** scripted second-opinion text clearly labeled as a demonstration, including an explicit rejection of the unsafe candidate.
- **Policy-aware checks:** real local Python checks for new imports and a small-diff heuristic (not semantic verification).
- **Evidence Passport:** download a structured JSON report with the selected finding, demo activity events, selected patch, real syntax/policy results, scripted review, and explicit scanner/model limitations.
- **Original preservation:** the UI only constructs patches; it never modifies the source sample.

**Still not integrated:** Nemotron API, real OpenGrep execution, actual autonomous reviewer, or security assurance. The review panel must not be presented as a real model finding.

Run unit tests from the project root with `python3 -m unittest discover -s tests -p 'test_*.py'`.

## v5 — interaction and code-transformation visuals

- The **Run demo** button finishes instantly by default. In the sidebar, turn on **Animate demo run (2 seconds)** to view an explicitly scripted loading sequence with a CSS code spiral and step progress.
- **Code transformation visual** is a collapsible, static preview below the Patch Arena; the animation is displayed during the optional demo run.
- The side-by-side comparison highlights added/changed lines in green and removed/changed lines in red, with line numbers and symbols. The highlights are based on Python `difflib` and escaped before HTML rendering.
- Sidebar toggles let you hide highlights and the transformation visual. A quick-select button chooses the recommended sample patch.
- Animation respects the operating system's reduced-motion preference. No AI or OpenGrep integration is implied by these visual elements.


### v8 appearance and animation
Dark mode now explicitly clears white Streamlit markdown/section surfaces, including sidebar headings and review sections. The Nemotron cube uses larger NVIDIA-green glyphs on all six faces. The optional two-second animation uses a translucent copy of the source code: it moves to the center, completes one 360° rotation, then travels to the proposed-fix card. This remains a visual demo, not a real scanner/model execution.

## Veridex v12 branding and visual updates

Geometric Verified Shield in `assets/veridex-shield.svg`; tagline “Don’t just fix it. Verify it.”; faster optional 1.15-second code animation; theme-aware transparent Executive Overview severity chart. This is still a simulated agent demo, not a live NVIDIA Nemotron integration.
